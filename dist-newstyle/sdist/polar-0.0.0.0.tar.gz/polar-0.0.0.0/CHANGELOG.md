# Changelog

`polar` uses [PVP Versioning][1].

## 0.0.0.0

* Initially created.

[1]: https://pvp.haskell.org
