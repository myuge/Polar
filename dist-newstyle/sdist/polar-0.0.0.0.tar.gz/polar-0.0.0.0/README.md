# polar

[![Hackage](https://img.shields.io/hackage/v/polar.svg?logo=haskell)](https://hackage.haskell.org/package/polar)
[![Stackage Lts](http://stackage.org/package/polar/badge/lts)](http://stackage.org/lts/package/polar)
[![Stackage Nightly](http://stackage.org/package/polar/badge/nightly)](http://stackage.org/nightly/package/polar)
[![GPL-3.0-only license](https://img.shields.io/badge/license-GPL--3.0--only-blue.svg)](LICENSE)

Exprerimentation on polar transformantions
